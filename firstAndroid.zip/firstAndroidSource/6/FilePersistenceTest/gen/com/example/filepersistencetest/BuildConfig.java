/** Automatically generated file. DO NOT MODIFY */
package com.example.filepersistencetest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}