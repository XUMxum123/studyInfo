/** Automatically generated file. DO NOT MODIFY */
package com.example.uicustomviews;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}